"use strict";

const ua = navigator.userAgent;
const clickEvent =
  ua.match(/iPad/i) || ua.match(/iPhone/) ? "touchstart" : "click";

/******************************************************************************
 * Modal window
 *****************************************************************************/
const paddingOffset = `${window.innerWidth - document.body.offsetWidth}px`;
const buttonOpenModal = document.querySelectorAll(".modal__open");
const modalContent = document.querySelectorAll("[data-windowid]");
let modalContentHTML = "";

class Modal {
  constructor() {
    const wrapper = document.querySelector(".wrapper");
    const modal = this;

    modal.create = function (className) {
      modal.wrapper = document.createElement("div");
      modal.window = document.createElement("div");
      modal.content = document.createElement("div");
      modal.closeButton = document.createElement("div");

      modal.wrapper.classList.add("modal__wrapper");
      modal.window.classList.add("modal");
      modal.window.classList.add(className);
      modal.content.classList.add("modal__content");
      modal.closeButton.classList.add("modal__close");

      document.body.insertBefore(modal.wrapper, wrapper);
      modal.wrapper.appendChild(modal.window);
      modal.window.appendChild(modal.closeButton);
      modal.window.appendChild(modal.content);
    };

    modal.open = function () {
      modal.wrapper.classList.add("modal__wrapper-active");
      modal.window.classList.add("modal-fade-in");
      modal.closeButton.classList.add("modal__close-active");

      modal.content.innerHTML = modalContentHTML;

      document.body.style.overflow = "hidden";
      document.body.style.paddingRight = paddingOffset;
      document.querySelector(".header").style.paddingRight = paddingOffset;
      document.querySelector(".footer").style.paddingRight = -paddingOffset;

      return modal;
    };

    modal.close = function () {
      modal.wrapper.classList.remove("modal__wrapper-active");
      modal.closeButton.classList.remove("modal__close-active");
      modal.wrapper.remove();

      document.body.style.overflow = "unset";
      document.body.style.paddingRight = "0";
      document.querySelector(".header").style.paddingRight = "0";
      document.querySelector(".footer").style.paddingRight = "0";

      return modal;
    };

    document.addEventListener(clickEvent, (e) => {
      if (e.target === modal.wrapper || e.target === modal.closeButton) {
        modal.close();
      }
    });
  }
}

const modal = new Modal();

function addingContent(btn) {
  for (let i = 0; i < modalContent.length; i += 1) {
    if (modalContent[i].dataset.windowid === btn.dataset.buttonid) {
      modal.create(modalContent[i].dataset.type);
      modalContentHTML = modalContent[i].innerHTML;
    }
  }
}

buttonOpenModal.forEach((button) => {
  button.addEventListener(clickEvent, (e) => {
    e.preventDefault();

    addingContent(button);
    modal.open();
  });
});

/******************************************************************************
 * Youtube iframe video
 *****************************************************************************/

function UrlExists(url) {
  const http = new XMLHttpRequest();
  http.open("HEAD", url, false);
  http.send();
  return http.status !== 404;
}

function generateURL(id) {
  const query =
    "?rel=0&showinfo=0&autoplay=1&modestbranding=1&iv_load_policy=3";
  return `https://www.youtube.com/embed/${id}${query}`;
}

function createIframe(id) {
  const iframe = document.createElement("iframe");

  iframe.setAttribute("allowfullscreen", "");
  iframe.setAttribute("frameborder", "0");
  iframe.allow =
    "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture";
  iframe.setAttribute("src", generateURL(id));
  iframe.classList.add("video__media");

  return iframe;
}

function setupVideo(video) {
  const vID = video.dataset.id;
  const posterSrc = video.dataset.postersrc;
  const posterCheck = +video.dataset.postercheck;
  const linkContent = `
    <picture>
      <source srcset="https://i.ytimg.com/vi_webp/${vID}/maxresdefault.webp" type="image/webp">
      <img class="video__media" src="https://i.ytimg.com/vi/${vID}/maxresdefault.jpg" alt="poster">
    </picture>
  `;
  const buttonContent = `
    <svg class="play" width="100" height="100" viewbox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path class="play__circle" d="M50 100c27.614 0 50-22.386 50-50S77.614 0 50 0 0 22.386 0 50s22.386 50 50 50z" />
      <path class="play__triangle" d="M69.166 48.463c.255.163.466.39.612.658a1.843 1.843 0 010 1.757 1.802 1.802 0 01-.612.659L40.726 69.72c-1.185.758-2.726-.11-2.726-1.538V31.818c0-1.427 1.54-2.296 2.727-1.537l28.439 18.182z" />
    </svg>
  `;

  const link = document.createElement("a");
  link.classList.add("video__link");
  link.setAttribute("href", "https://youtu.be/ID".replace("ID", vID));

  if (posterCheck === 1) {
    if (posterSrc && UrlExists(posterSrc)) {
      link.innerHTML = `<img class="video__media" src="${posterSrc}" alt="poster">`;
    } else {
      link.innerHTML = linkContent;
    }
  } else {
    link.innerHTML = linkContent;
  }

  video.appendChild(link);

  const button = document.createElement("button");
  button.classList.add("video__button");
  button.setAttribute("type", "button");
  button.setAttribute("aria-label", "play");
  button.innerHTML = buttonContent;
  video.appendChild(button);

  video.addEventListener("click", (e) => {
    e.preventDefault();

    if (!video.classList.contains("bonus__video")) {
      const iframe = createIframe(vID);
      link.remove();
      button.remove();
      video.appendChild(iframe);
    }
  });

  link.removeAttribute("href");
  video.classList.add("video--enabled");
}

function findVideo() {
  const videos = document.querySelectorAll(".video");
  for (let i = 0; i < videos.length; i += 1) {
    setupVideo(videos[i]);
  }
}

findVideo();

/******************************************************************************
 * Installment Plan
 *****************************************************************************/

function installmentPlan() {
  const ccLocalParams = "&cred_type=8&maxpay=12";
  const locationLang = window.location.pathname.split("/")[1];
  const installmentPlanBox = document.querySelector(".installment-plan");
  const installmentPlanMonths = ccLocalParams.split("=")[2];
  const credType = +ccLocalParams.split("=")[1].split("&")[0];

  if (credType !== 1) {
    switch (locationLang) {
      case "ru":
        installmentPlanBox.innerHTML = `(до <span>${installmentPlanMonths}</span> платежей без %)`;
        break;
      case "he":
        installmentPlanBox.innerHTML = `(עד <span>${installmentPlanMonths}</span> תשלומים ללא ריבית)`;
        break;
      case "ar":
        installmentPlanBox.innerHTML = `(حتى <span>${installmentPlanMonths}</span> أقساط بدون ربا)`;
        break;

      default:
        installmentPlanBox.innerHTML = `(до <span>${installmentPlanMonths}</span> платежей без %)`;
        break;
    }
  } else {
    installmentPlanBox.innerHTML = "";
  }
}

installmentPlan();

window.addEventListener("load", () => {});
